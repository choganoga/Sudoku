The XML code from the highScores.xml file contains a hardcoded list of players. 

These values are read using an XMLHttpRequest and inserted into the navbar on the
Sudoku game page. The XML seems to only display properly in Firefox when viewing the pages 
locally.